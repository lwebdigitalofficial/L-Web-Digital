const nav = document.getElementById('nav');
const hamburger = document.querySelector('.hamburger');
hamburger.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  if(open){
    nav.style.display='flex';
    nav.style.position='absolute';
    nav.style.top='76px';
    nav.style.left='0';
    nav.style.right='0';
    nav.style.background='#050507';
    nav.style.flexDirection='column';
    nav.style.padding='10px 25px 20px';
    nav.style.gap='0';
  }else{
    nav.removeAttribute('style');
  }
});
document.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>nav.removeAttribute('style')));
document.getElementById('year').textContent = new Date().getFullYear();
const contactForm = document.getElementById('contactForm');
const successBox = document.getElementById('success');

contactForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const button = contactForm.querySelector('button[type="submit"]');
  const originalText = button.textContent;
  button.disabled = true;
  button.textContent = 'Sending…';
  successBox.style.display = 'none';

  try {
    const response = await fetch(contactForm.action, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(Object.fromEntries(new FormData(contactForm)))
    });
    const data = await response.json();

    if (!response.ok || data.success === false) {
      throw new Error(data.message || 'Unable to send inquiry.');
    }

    successBox.textContent = 'Thanks! Your inquiry has been sent successfully. We will contact you soon.';
    successBox.style.display = 'block';
    contactForm.reset();
  } catch (error) {
    successBox.textContent = 'Sorry, your inquiry could not be sent. Please WhatsApp or email us using the contact options below.';
    successBox.style.display = 'block';
  } finally {
    button.disabled = false;
    button.textContent = originalText;
  }
});
const links=[...document.querySelectorAll('nav a')];
const sections=[...document.querySelectorAll('main section[id]')];
window.addEventListener('scroll',()=>{
  let current='home';
  sections.forEach(s=>{ if(window.scrollY >= s.offsetTop-130) current=s.id; });
  links.forEach(l=>l.classList.toggle('active',l.getAttribute('href')==='#'+current));
});
